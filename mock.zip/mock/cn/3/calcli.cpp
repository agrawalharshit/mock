#include<stdio.h>
#include<string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<math.h>
#include<fstream>
using namespace std;

int main()
{
	int sock, c, read_size, client_sock;
	struct sockaddr_in ser, cli;
	char word[2000], oper[2], erro[2000];
	int choice, number1, number2,result,err = 0;
	
	ifstream f1;
	
	//Socket creation
	sock= socket(AF_INET, SOCK_STREAM, 0);
	if(sock <0)
	{
		printf("Could not create socket\n");
		return 1;
	}
	puts("Socket Created");
	
	//Prepare the sockaddr_in struct
	ser.sin_family = AF_INET;
	ser.sin_addr.s_addr = inet_addr("127.0.0.1");
	ser.sin_port = htons(8888);
	
	//Connect
	if( connect(sock, (struct sockaddr *)&ser, sizeof(ser)) < 0)
	{
		printf("Connect Failed");
		return 1;
	}
	puts("Connected\n");
	
	//keep communcating
	while(1)
	{
		char word[2000]={};
		printf("\n\t1.Say Hello\n\t2.File Transfer\n\t3.Calculator");
		printf("\nEnter choice=");
		scanf("%d",&choice);
		send(sock, &choice, sizeof(int), 0 );
		switch(choice)
		{	
			fflush(stdout);
			fflush(stdin);
			case 1:
				strcpy(word,"Hello");
				if( send(sock, word, strlen(word), 0 ) < 0)
				{
					puts("\nSend Failed");
					return 1;
				}
		
				if( recv(sock, word, 6, 0) < 0)
				{
					puts("\nrecv Failed");
					break;
				}
				printf("\nServer says %s", word);
				fflush(stdout);
				fflush(stdin);
				break;
			case 2:
				f1.open("ques.txt",ios::in);
				while(!f1.eof())
				{
					if(f1.eof())
						break;
					f1.getline(word,2000);
					printf("%s\n",word);
					if( send(sock, word, strlen(word), 0 ) < 0)
					{
						puts("\nSend Failed");
						break;
					}
					printf("2");
					if( recv(sock, &err, sizeof(int), 0) < 0)
					{
						puts("\nrecv Failed");
						break;
					}
					char word[2000]={};
					fflush(stdout);
					fflush(stdin);
				}
				strcpy(erro,"-1");
				printf("%s\n",erro);
				fflush(stdout);
				fflush(stdin);
				if( send(sock, erro, strlen(erro), 0 ) < 0)
					{
						puts("\nSend Failed");
						break;
					}
					
				if( recv(sock, &err, sizeof(int), 0) < 0)
					{
						puts("\nrecv Failed");
						break;
					}
					
				f1.close();
				fflush(stdout);
				fflush(stdin);
				break;
			case 3:
				printf("Enter number1=");
				scanf("%d",&number1);
				printf("Enter number2=");
				scanf("%d",&number2);
				printf("Enter operator=");
				scanf("%s",oper);
				fflush(stdout);
				fflush(stdin);
				if( send(sock, &number1, sizeof(int), 0 ) < 0)
				{
					puts("\nSend Failed");
					break;
				}
				fflush(stdout);
				fflush(stdin);
				if( send(sock, &number2, sizeof(int), 0 ) < 0)
				{
					puts("\nSend Failed");
					break;
				}
				fflush(stdout);
				fflush(stdin);
				if( send(sock, oper, sizeof(oper), 0 ) < 0)
				{
					puts("\nSend Failed");
					break;
				}	
				fflush(stdout);
				fflush(stdin);
				if( recv(sock, &err, sizeof(int), 0) < 0)
				{
					puts("\nrecv Failed");
					break;
				}
				recv(sock, &result, sizeof(int), 0);
				printf("\nResult = %d",result);
				fflush(stdout);
				fflush(stdin);
				break;
			default:printf("\nWrong choice");
		}
		fflush(stdout);
		fflush(stdin);
		
	}
	close(sock);
	
	return 0;
}


