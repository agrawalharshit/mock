gcc sniffer.c -o sniffer -lpcap
sudo ./sniffer tcp

//tcp can be replaced by ip/udp
ethernet not working

