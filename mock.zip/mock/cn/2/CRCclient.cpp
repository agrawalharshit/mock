#include<stdio.h>
#include<string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>

int main()
{
	int sock, c, read_size, client_sock;
	struct sockaddr_in ser, cli;
	char datarec[30];
	//Socket creation
	sock= socket(AF_INET, SOCK_STREAM, 0);
	if(sock <0)
	{
		printf("Could not create socket\n");
		return 1;
	}
	puts("Socket Created");
	
	//Prepare the sockaddr_in struct
	ser.sin_family = AF_INET;
	ser.sin_addr.s_addr = inet_addr("127.0.0.1");
	ser.sin_port = htons(8001);
	
	//Connect
	if( connect(sock, (struct sockaddr *)&ser, sizeof(ser)) < 0)
	{
		printf("Connect Failed");
		return 1;
	}
	puts("Connected\n");
	
	//keep communcating
	while(1)
	{
		int fs=8,cnt=7;
		int f1;
		char c;
		int f[20]={0,0,0,0,0,0,0,0};
		printf("\nEnter frame : ");
		scanf("%c",&c);
		f1=c;
		while(f1>0)
		{
			f[cnt--]=f1%2;
			f1/=2;
		}		
		int gs=9;
		int g[20]={1,0,0,0,0,0,1,1,1};
		int rs=gs-1;
		printf("\nNumbers of 0s to be appended : %d",rs);
		
		for(int i=fs;i<fs+rs;i++)
			f[i]=0;
		int t[20];
		for(int i=0; i<20; i++)
			t[i]=f[i];
		printf("\nMessage after appending 0s : ");
		for(int i=0; i<fs+rs; i++)
			printf("%d",t[i]);
		for(int i=0; i<fs; i++)
		{
			int j=0;
			int k=i;
			if(t[k]>=g[j])
			{
				for(j=0,k=i;j<gs;j++,k++)
				{
					if(t[k]==g[j])
						t[k]=0;
					else
						t[k]=1;
				}
			}
		}
		int crc[15];
		for(int i=0, j=fs; i<rs; i++,j++)
			crc[i]=t[j];
		printf("\nCRC Bits : ");
		for(int i=0; i<rs; i++)
			printf("%d",crc[i]); 
		printf("\nTransmitted Frame : ");
		char tf[30];
		for(int i=0; i<fs; i++)
			tf[i]=f[i]+48;
		for(int i=fs,j=0; i<fs+rs; i++,j++)
			tf[i]=crc[j]+48;
		tf[fs+rs]='\0';
		printf("%s",tf);
		if(send(sock, tf, strlen(tf), 0 ) < 0)
		{
			puts("Send Failed");
			return 1;
		}
		send(sock,"\0", 1, 0 );
		break;
			
		
	}
	close(sock);
	
	return 0;
}
