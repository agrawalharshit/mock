#include<stdio.h>
#include<string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>

int main()
{
	int sock_desc, client_sock, c, read_size,pos,x;
	struct sockaddr_in ser,cli;
	char datarec[30];
	char choice;
	
	//Socket creation
	sock_desc = socket(AF_INET, SOCK_STREAM, 0);
	if(sock_desc <0)
	{
		printf("Could not create socket\n");
		return 1;
	}
	puts("Socket Created");
	
	//Prepare the sockaddr_in struct
	ser.sin_family = AF_INET;
	ser.sin_addr.s_addr = INADDR_ANY;
	ser.sin_port = htons(8001);
	
	//bind
	if( bind(sock_desc, (struct sockaddr *)&ser, sizeof(ser)) < 0)
	{
		printf("Bind Failed");
		return 1;
	}
	puts("Bind Done");
	
	//Listen
	listen(sock_desc, 3);
	
	//Accept incomin
	puts("Waiting for incoming connection");
	c = sizeof(struct sockaddr_in);
	
	//accept connection
	client_sock = accept(sock_desc, (struct sockaddr *)&cli, (socklen_t*)&c);
	if(client_sock < 0)
	{
		printf("Accept Failed");
		return 1;
	}
	puts("Connection Accepted");
	char t1[30],g1[30];
		
	//Recievce
	while((read_size = recv(client_sock, t1, 40, 0)) > 0)
	{	
		printf("\nReceived Frame: ");
		printf("%s",t1);
		int t[30],n;
		int gs=9;
		int g[20]={1,0,0,0,0,0,1,1,1};
		int fs=strlen(t1)-8,rs=8;
		for(int i=0; i<strlen(t1); i++)
			t[i]=t1[i]-48;
		for(int i=0; i<strlen(t1); i++)
		{
			int j=0;
			int k=i;
			if(t[k]>=g[j])
			{
				for(j=0,k=i; j<strlen(g1); j++,k++)
				{
					if(t[k]==g[j])
						t[k]=0;
					else
						t[k]=1;
				}
			}
		} 
		printf("\nRemainder : ");
		int rem[15];
		for(int i=fs,j=0; i<strlen(t1); i++,j++)
			rem[j]=t[i];	
			
			
		for(int i=0; i<rs; i++)
			printf("%d",rem[i]);
		int flag=0;
		for(int i=0; i<rs; i++)
		{
			if(rem[i]!=0)
				flag=1;
		}	
		if(flag==0)
			printf("\nRemainder is 0 hence message transmitted without error.");
		else
			printf("\nRemainder is not 0 hence message transmiited with error.");
		break;
	
	}
	if(read_size == 0)
	{
		puts("Client disconnected");
		fflush(stdout);
	}
	else if(read_size == -1)
	{
		perror("Recv Failed");
	}
	
	close(sock_desc);
	
	return 0;
}

