#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include<stdlib.h>
#include <string.h>
#include <arpa/inet.h>
 

#define PCKT_LEN 8192
unsigned short csum(unsigned short *buf, int nwords)
{       //
        unsigned long sum;
        for(sum=0; nwords>0; nwords--)
                sum += *buf++;
        sum = (sum >> 16) + (sum &0xffff);
        sum += (sum >> 16);
        return (unsigned short)(~sum);
}

int main(int argc, char *argv[])
{
int sd;

char buffer[PCKT_LEN];

struct iphdr *ip = (struct iphdr *) buffer;
struct udphdr *udp = (struct udphdr *) (buffer + sizeof(struct ip));

struct sockaddr_in sin, din;
int one = 1;
const int *val = &one;
 
memset(buffer, 0, PCKT_LEN);
 
if(argc != 5)
{
printf("- Invalid parameters!!!\n");
printf("- Usage %s <source hostname/IP> <source port> <target hostname/IP> <target port>\n", argv[0]);
exit(-1);
}
 

sd = socket(PF_INET, SOCK_RAW, IPPROTO_UDP);
if(sd < 0)
{
perror("socket() error");

exit(-1);
}
else
printf("socket() - Using SOCK_RAW socket and UDP protocol is OK.\n");

sin.sin_family = AF_INET;
din.sin_family = AF_INET;

sin.sin_port = htons(atoi(argv[2]));
din.sin_port = htons(atoi(argv[4]));

sin.sin_addr.s_addr = inet_addr(argv[1]);
din.sin_addr.s_addr = inet_addr(argv[3]);
ip->ihl = 5;
ip->version = 4;
ip->tos = 16; 
ip->tot_len = sizeof(struct iphdr) + sizeof(struct udphdr);
ip->id = htons(54321);
ip->frag_off = 0;
ip->ttl = 255; 
ip->protocol = IPPROTO_UDP; 

ip->saddr = inet_addr(argv[1]);

ip->daddr = inet_addr(argv[3]);

udp->source = htons(atoi(argv[2]));

udp->dest = htons(atoi(argv[4]));
udp->len = htons(sizeof(struct udphdr));

ip->check = csum((unsigned short *)buffer, sizeof(struct iphdr) + sizeof(struct udphdr));

if(setsockopt(sd, IPPROTO_IP, IP_HDRINCL, val, sizeof(one)) < 0)
{
perror("setsockopt() error");
exit(-1);
}
else
printf("setsockopt() is OK.\n");

printf("Trying...\n");
printf("Using raw socket and UDP protocol\n");
printf("Using Source IP: %s port: %u, Target IP: %s port: %u.\n", argv[1], atoi(argv[2]), argv[3], atoi(argv[4]));
 
int count;
for(count = 1; count <=20; count++)
{
if(sendto(sd, buffer, ip->tot_len, 0, (struct sockaddr *)&sin, sizeof(sin)) < 0)
{
perror("sendto() error");
exit(-1);
}
else
{
printf("Count #%u - sendto() is OK.\n", count);
sleep(2);
}
}
close(sd);
return 0;
}
