import javax.naming.directory.Attributes;
import javax.naming.directory.InitialDirContext;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

class Addr
{
   public static void main(String args[])
   {
      String ip;
      System.out.println("Enter url or ip address : ");
      Scanner sc = new Scanner(System.in);
      ip = sc.next(); 
         
      try
      {
         if(ip.charAt(0) >='0' && ip.charAt(0) <='9')
         {
            byte[] b = new byte[4];
            String[] bytes = ip.split("[.]");
            for (int i = 0; i < bytes.length; i++)
            {
                    b[i] = new Integer(bytes[i]).byteValue();
            }
            InetAddress in=InetAddress.getByAddress(b);
            System.out.println("The url of given ip Address is:"+in.getHostName());
         }
         else
         {
            InetAddress in=InetAddress.getByName(ip);
            System.out.println("The ip Address of site is:"+in.getHostAddress());
         }
      
      }
      catch(Exception e)
      {
         System.out.println("Some Exception has occurred with details"+e.getMessage());
      }
   }
}
