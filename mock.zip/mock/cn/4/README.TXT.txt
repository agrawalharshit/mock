Hiiii Humansss!!
*Peer.java files are to be used for peer-to-peer chating. Run the SerPeer first and then CliPeer.

*Multi.java for Multichat. Run SerMulti and then run the CliMulti as many times as you want. Enter any name and chat away. For localhost address only.