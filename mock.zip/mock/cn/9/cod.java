import java.util.Scanner;
class cod
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n,e;
		System.out.print("Enter number of nodes : ");
		n=sc.nextInt();
		System.out.print("Enter number of edges : ");
		e=sc.nextInt();
		int adj[][]=new int[n+1][n+1];
		int i,j;
		for(i=1;i<n+1;i++)
			for(j=1;j<n+1;j++)
			{
				if(i==j)
					adj[i][j]=0;
				else
					adj[i][j]=999;
			}
		System.out.println("\t\tEnter edge details");
		System.out.println("Node1	Node2	Weight ");
		int a,b,x;
		for(i=0;i<e;i++)
		{
			a=sc.nextInt();
			b=sc.nextInt();
			x=sc.nextInt();
			adj[a][b]=adj[b][a]=x;				
				
		}
		System.out.println("\t\tInitial routing table");
		for(i=1;i<n+1;i++)
		{
			System.out.println("Router"+i);
			System.out.println("Destination Cost Next");
			for(j=1;j<=n;j++)
			{
				if(adj[i][j]!=999)
				{
					if(adj[i][j]==-1)
						System.out.println(j+"\t"+adj[i][j]+" \t-");
					else
						System.out.println(j+"\t"+adj[i][j]+"\t"+adj[i][j]);
				}
				else
					System.out.println(j+"\tinf");
			}
			System.out.println("\n\n");
		}
		System.out.print("\t\tLSD\n\n");
		System.out.print("    ");
		for(i=1;i<n+1;i++)
			System.out.print(i+"   ");
		System.out.println();
		for(i=1;i<n+1;i++)
		{	System.out.print(i+"   ");
			for(j=1;j<n+1;j++)
			{
				if(adj[i][j]==999)
					System.out.print("inf ");
				else
					System.out.print(adj[i][j]+"   ");
			}
			System.out.println();
		}
		for(i=1;i<n+1;i++)
		{
			int visited[]=new int[n+1];
			for(j=1;j<=n;j++)
				visited[j]=0;
			int distance[]=new int[n+1];
			for(j=1;j<=n;j++)
				distance[j]=adj[i][j];
			int next[]=new int[n+1];
			for(j=0;j<n+1;j++)
				next[j]=-1;
			distance[i]=0;
			int k;
			for(j=1;j<=n;j++)
			{
				int min=999;
				x=0;
				for(k=1;k<=n;k++)
					if(distance[k]<min&&visited[k]==0)
					{
						min=distance[k];
						x=k;
					}
				visited[x]=1;
				for(k=1;k<n+1;k++)
					if(distance[k]>distance[x]+adj[x][k]&&visited[k]==0)
					{	distance[k]=distance[x]+adj[x][k];
						next[k]=x;
					}
			}
			System.out.println("Router"+i);
			System.out.println("Destination Cost Next");
			for(k=1;k<=n;k++)
			{
				if(distance[k]!=999)
				{
					if(next[k]==-1)
						System.out.println(k+"\t"+distance[k]+" \t-");
					else
						System.out.println(k+"\t"+distance[k]+"\t"+next[k]);
				}
				else
					System.out.println(k+"\tinf");	
			}		
		}		
	}		
}
