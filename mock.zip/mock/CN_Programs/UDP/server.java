import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class server
{
	public static void main(String args[]) throws IOException
	{
		DatagramSocket ds=new DatagramSocket(3333);
		InetAddress add=InetAddress.getByName("10.12.1.74");	  
		byte[] buffer1=new byte[2048];
		byte[] buffer2=new byte[2048];
		String str="";
		while(!str.equals("stop"))
		{
			DatagramPacket dp=new DatagramPacket(buffer1,buffer1.length);
			ds.receive(dp);
			buffer1=dp.getData();
			str=new String(buffer1,StandardCharsets.UTF_8);
			System.out.println("Client:- "+str);
			System.out.print("Server:- ");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			str=br.readLine();
			buffer2=str.getBytes();
			DatagramPacket dp1=new DatagramPacket(buffer2,buffer2.length,add,4444);
			ds.send(dp1);
		}
	}

}
