import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
public class client
{
	public static void main(String args[])throws IOException
    {
		DatagramSocket ds=new DatagramSocket(3333);
		InetAddress add=InetAddress.getByName("10.12.1.74");	    
		byte[] buffer1=new byte[2048];
		byte[] buffer2=new byte[2048];
		String str="";
		while(!str.equals("stop"))
		{
			System.out.print("Client: ");
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			str=br.readLine();
			buffer1=str.getBytes();
			DatagramPacket dp=new DatagramPacket(buffer1,buffer1.length,add,4444);
			ds.send(dp);
			DatagramPacket dp1=new DatagramPacket(buffer2,buffer2.length);
			ds.receive(dp1);
			buffer2=dp1.getData();
			str=new String(buffer2,StandardCharsets.UTF_8);
			System.out.println("Server says: "+str);
		}
	}
}
