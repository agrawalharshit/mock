import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ServerUdpMulti
{
	public static void main(String args[]) throws IOException
	{
		DatagramSocket ds=new DatagramSocket(3333);	  
		byte[] buffer1=new byte[65535];
		byte[] buffer2=new byte[65535];
		String str="";
		while(!str.equals("stop"))
		{
			DatagramPacket dp=new DatagramPacket(buffer1,buffer1.length);
			ds.receive(dp);
			buffer1=dp.getData();
			str=new String(buffer1,StandardCharsets.UTF_8);
			System.out.println("Client:- "+str);
			InetAddress add=dp.getAddress();
			int port=dp.getPort();
			System.out.print("Server:- ");
			Scanner In=new Scanner(System.in);
			str=In.nextLine();
			buffer2=str.getBytes();
			DatagramPacket dp1=new DatagramPacket(buffer2,buffer2.length,add,port);
			ds.send(dp1);
		}
	}

}
