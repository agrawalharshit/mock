import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ClientUdpMulti
{
	public static void main(String args[])throws IOException
    {
		DatagramSocket ds=new DatagramSocket(3333);
		InetAddress add=InetAddress.getByName("10.12.1.74");	    
		byte[] buffer1=new byte[65535];
		byte[] buffer2=new byte[65535];
		String str="";
		while(!str.equals("stop"))
		{
			System.out.print("Client:- ");
			Scanner In=new Scanner(System.in);
			str=In.nextLine();
			buffer1=str.getBytes();
			DatagramPacket dp=new DatagramPacket(buffer1,buffer1.length,add,3333);
			ds.send(dp);
			DatagramPacket dp1=new DatagramPacket(buffer2,buffer2.length);
			ds.receive(dp1);
			buffer2=dp1.getData();
			str=new String(buffer2,StandardCharsets.UTF_8);
			System.out.println("Server:- "+str);
		}
	}
}
