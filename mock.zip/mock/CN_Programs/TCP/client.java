import java.io.*;
import java.net.*;

public class client
{
	public static void main(String [] args) throws IOException
	{
		Socket s=new Socket("localhost",5555);
		DataInputStream dis=new DataInputStream(s.getInputStream());
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		String str="";
		while(!str.equals("stop"))
		{
			System.out.println("Enter the message to send to server: ");
			str=br.readLine();
			
			dos.writeUTF(str);
			//dos.flush();
		
			str=dis.readUTF();
			System.out.println("Server said: "+str);
			
		}
		dis.close();
		dos.close();
		s.close();
	}
}
