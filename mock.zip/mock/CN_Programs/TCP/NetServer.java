// echo server

import java.io.*;
import java.net.*;


public class NetServer
{
  public static void main(String args[]) throws IOException
  {
    ServerSocket ss2=new ServerSocket(4445);//it will create new serversocket to initiate connection
    System.out.println("Server Listening......");
  
    while(true)
    {
        try
	{
      	    Socket s= ss2.accept();//it will accept connection from multiple users if there port number is same as server port number
            System.out.println("connection Established");
            ServerThread st=new ServerThread(s);//it will create new thread if user request and it will run multiple times means it will accept multiple users by using while loop
            st.start();//it will start the run method of server thread class

        }
        catch(Exception e)
	{      
	    System.out.println("Connection Error");//if any exception is throw then it will catch that exception and it will displays exception message where the exception is occured
	}
     }
  }
}

class ServerThread extends Thread
{  
    String line=null;
    BufferedReader br = null;
    DataOutputStream dos=null;
    DataInputStream dis=null;
    Socket s=null;
   
    public ServerThread(Socket s)
	{
        this.s=s;  //invoke or initiate current class constructor
  	 }

    public void run()
    {
   	 try
   	 {
    	    br= new BufferedReader(new InputStreamReader(System.in));
    	    dos=new DataOutputStream(s.getOutputStream());
            dis=new DataInputStream(s.getInputStream());

   	 }
	catch(IOException e)
	{
        	System.out.println("IO error in server thread");
  	}

  	try 
	{
	   line="";
     	   while(!line.equals("stop"))
	   {
       		line=dis.readUTF();  
		System.out.println("client says: "+line); 
		dos.flush();  
		String str1=br.readLine();
		System.out.println("Server says: "+str1);
				dos.writeUTF(str1);
	    }   
        } 
	catch (IOException e)
	{

	  System.out.println("IO Error/ Client ");
        }
        catch(NullPointerException e)
	{
      	   System.out.println("IO Error/ Client");
  	}
		
finally{
try{
   br.close(); 
  dos.close();
  dis.close();
  s.close();
}
  catch(IOException ie){
        System.out.println("Socket Close Error");
}}
}
}
