import java.io.*;
import java.net.*;

public class server
{
	public static void main(String [] args) throws Exception
	{
		ServerSocket ss=new ServerSocket(5555);
		Socket s=ss.accept();
		DataInputStream dis=new DataInputStream(s.getInputStream());
		DataOutputStream dos=new DataOutputStream(s.getOutputStream());
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		String str="";
		while(!str.equals("stop"))
		{
			str=dis.readUTF();
			System.out.println("The client said: "+str);
			
			System.out.println("Enter the reply: ");
			str=br.readLine();
			dos.writeUTF(str);
			
			//dos.flush();
		}
		dos.close();
		dis.close();
		s.close();
		ss.close();
	}
}
