// A simple Client Server Protocol .. Client for Echo Server


import java.io.*;
import java.net.*;

public class NetClient {

public static void main(String args[]) throws IOException
{
    Socket s1=null;
    String line=null;
    BufferedReader br=null;
    //BufferedReader br1=null;
    DataOutputStream dos=null;
     DataInputStream dis=null;

    try {
        s1=new Socket("10.12.1.170", 4445); 
        br= new BufferedReader(new InputStreamReader(System.in));
      dis=new DataInputStream(s1.getInputStream());
        dos= new DataOutputStream(s1.getOutputStream());
    }
   catch (IOException e){
        e.printStackTrace();
        System.err.print("IO Exception");
    }

    System.out.println("Enter Data to echo Server ( Enter QUIT to end):");

    String response="";
    try{
        line=br.readLine(); 
        while(!line.equals("QUIT"))
	{
	     dos.writeUTF(line);  
		dos.flush(); 
		  
               String str1=dis.readUTF();
               System.out.println("Server says: "+str1);
		System.out.println("Enter Data to echo Server ( Enter QUIT to end):");
               line=br.readLine();
              
        }
    }
    catch(IOException e){
        e.printStackTrace();
    System.out.println("Socket read Error");
    }
    finally{

     //   br1.close();
	dos.close();
	br.close();
	s1.close();
        System.out.println("Connection Closed");

    }

}
}
