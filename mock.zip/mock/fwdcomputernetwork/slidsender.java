//SENDER PROGRAM

import java.net.*;
import java.io.*;
import java.rmi.*;
import java.util.*;
public class slidsender
{
public static void main(String args[])throws Exception
{
ServerSocket ser=new ServerSocket(1024);
Socket s=ser.accept();
System.out.println("Done!\n");

Scanner in=new Scanner(System.in);
Scanner in1=new Scanner(System.in);

//BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
/*DataInputStream in=new DataInputStream(System.in);
DataInputStream in1=new DataInputStream(s.getInputStream());*/
String sbuff[]=new String[8];
PrintStream p;
int sptr=0,sws=8,nf,ano,i;
String ch;
do
{
p=new PrintStream(s.getOutputStream());
System.out.print("Enter the no. of frames : ");
nf=in.nextInt();
//nf=Integer.parseInt(in.readLine());
p.println(nf);
if(nf<=sws-1) 
{

System.out.println("Enter "+nf+" Messages to be send\n"); 
for(i=1;i<=nf;i++) 
{ 
sbuff[sptr]=in.nextLine();
//sbuff[sptr]=in.readLine(); 
p.println(sbuff[sptr]); 
sptr=++sptr%8; 
} 
sws-=nf; 
System.out.print("Acknowledgment received"); 
ano=in1.nextInt();
//ano=Integer.parseInt(in1.readLine()); 
System.out.println(" for "+ano+" frames"); 
sws+=nf; 
} 
else 
{ 
System.out.println("The no. of frames exceeds window size"); 
break; 
} 
System.out.print("\nDo you wants to send some more frames : "); 
ch=in.nextLine();
//ch=in.readLine();
p.println(ch); 
} 
while(ch.equals("yes")); 
s.close(); 
} 
}
