#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<string.h>
#include<time.h>
#include<stdlib.h>
#include<ctype.h>
#include<arpa/inet.h>

#define W 5
#define P1 50
#define P2 10

char a[10];
char b[10];
void alpha9(int);
void alp(int);

int main()
{
    struct sockaddr_in ser,cli;
    int s,n,sock,i,j,c=1,f;
    unsigned int s1;
    s=socket(AF_INET,SOCK_STREAM,0);
    ser.sin_family=AF_INET;
    ser.sin_port=6500;
    ser.sin_addr.s_addr=inet_addr("192.168.0.109");
    bind(s,(struct sockaddr *) &ser, sizeof(ser));
    listen(s,1);
    n=sizeof(cli);
    sock=accept(s,(struct sockaddr *)&cli, &n);
    printf("\nTCP Connection Established.\n");
    s1=(unsigned int) time(NULL);
    srand(s1);
    strcpy(b,"Time Out ");
    recv(sock,a,sizeof(a),0);
    f=atoi(a);
    while(1)
    {
        for(i=0;i<W;i++)
        {
            recv(sock,a,sizeof(a),0);
            if(strcmp(a,b)==0)
            {
                break;
            }
        }
        i=0;
        while(i<W)
        {
            L:
                j=rand()%P1;
            if(j<P2)
            {
                alp(c);
                send(sock,b,sizeof(b),0);
                goto L;
            }
            else
            {
                alpha9(c);
                if(c<=f)
                {
                    printf("\nFrame %s Received ",a);
                    send(sock,a,sizeof(a),0);
                }
                else
                {
                    break;
                }
                c++;
            }
            if(c>f)
            {
                break;
            }
            i++;
        }
    }
    close(sock);
    close(s);
    return 0;
}

void alpha9(int z)
{
    int k,i=0,j,g;
    k=z;
    while(k>0)
    {
        i++;
        k=k/10;
    }
    g=i;
    i--;
    while(z>0)
    {
        k=z%10;
        a[i]=k+48;
        i--;
        z=z/10;
    }
    a[g]='\0';
}

void alp(int z)
{
    int k,i=1,j,g;
    k=z;
    b[0]='N';
    while(k>0)
    {
        i++;
        k=k/10;
    }
    g=i;
    i--;
    while(z>0)
    {
        k=z%10;
        b[i]=k+48;
        i--;
        z=z/10;
    }
    b[g]='\0';
}
/*****OUTPUT******
aman@aman-Inspiron-5520:~$ cc SelRepR.c -o receiver
aman@aman-Inspiron-5520:~$ ./receiver

TCP Connection Established.

Frame 1 Received 
Frame 2 Received 
Frame 3 Received 
Frame 4 Received 
Frame 5 Received 
Frame 6 Received 
Frame 7 Received 
Frame 8 Received 
Frame 9 Received 
Frame 10 Received 
Frame 11 Received 
Frame 12 Received 
Frame 13 Received 
Frame 14 Received 
Frame 15 Received 
Frame 16 Received 
Frame 17 Received 
Frame 18 Received 
Frame 19 Received 
Frame 20 Received 
Frame 21 Received 
Frame 22 Received 
Frame 23 Received 
Frame 24 Received 
aman@aman-Inspiron-5520:~$
